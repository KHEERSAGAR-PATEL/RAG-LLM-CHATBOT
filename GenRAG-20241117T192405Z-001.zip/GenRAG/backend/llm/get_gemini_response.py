
import pathlib
import textwrap
import google.generativeai as genai
import os
import dotenv

dotenv.load_dotenv()


model = genai.GenerativeModel('gemini-pro')

def get_gemini_response(context, query):
    

    response = model.generate_content(f""" 
    Using the context given below answer the query.Dont make up the answers.Keep the answers informative but short.
                                    
    CONTEXT: {context}

    QUERY: {query}   

    Answer in 3-4 sentences.                            
                                    """)


    return response.text


